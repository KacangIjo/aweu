package com.example.videokycapi.service.impl;

import com.example.videokycapi.model.*;
import com.example.videokycapi.repository.KYCDetailRepository;
import com.example.videokycapi.service.IKycDetailService;
import com.google.gson.Gson;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.transaction.Transactional;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class KycDetailService implements IKycDetailService {

    @Value("${kyc.save.path}")
    String videoPath;

    @Value("${kyc.save.ip}")
    String videoIp;

    @Value("${kyc.save.port}")
    String videoPort;

    @Value("${kyc.save.mergeVideo}")
    String mergeVideo;

    @Value("${base.serviceomniurl}")
    private String serviceOmni;

    @Autowired
    public KYCDetailRepository kycDetailRepository;

    @Autowired
    private RestTemplate restTemplate;

    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    Logger logger = LogManager.getLogger(KycDetailService.class);
    Gson gson = new Gson();

    @Override
    public List<KYCDetailModel> getAllRecordDetail() {
        return kycDetailRepository.findAll();
    }

    @Transactional
    @Override
    public KYCDetailModel save(String generatedGuid, KYCDetailRequestModel request) {
        String messageId = UUID.randomUUID().toString();
        logger.error("Message Request Id : ".concat(messageId).concat("\n")
                .concat(new Object() {}
                        .getClass()
                        .getEnclosingMethod()
                        .getName())
                .concat("\n")
                .concat(gson.toJson(request)));

        Date date = new Date();

        Optional<KYCDetailModel> model = kycDetailRepository.findById(generatedGuid);

        if(model.isPresent()) {
            try {
                model.get().setId(generatedGuid);
                model.get().setAgentId(request.getAgentId());
                model.get().setCustomerId(request.getCustomerId());
                model.get().setCreatedBy(request.getCreatedBy());
                model.get().setInteractionId(request.getInteractionId());
                return kycDetailRepository.save(model.get());
            } catch (Exception ex) {
                logger.error("Message Response Id : ".concat(messageId).concat("\n")
                        .concat(new Object() {
                        }
                                .getClass()
                                .getEnclosingMethod()
                                .getName())
                        .concat("\n")
                        .concat(ex.getMessage()));
                return null;
            }
        }else{
            logger.error("Message Response Id : ".concat(messageId).concat("\n")
                    .concat(new Object() {
                    }
                            .getClass()
                            .getEnclosingMethod()
                            .getName())
                    .concat("\n")
                    .concat("No Data"));
            return null;
        }
    }

    @Override
    public ResponseEntity saveByAgent(KYCDetailRequestModel request) {
        //dipanggil ketika accepted dari agent
        String messageId = UUID.randomUUID().toString();
        logger.error("Message Request Id : ".concat(messageId).concat("\n")
                .concat(new Object() {}
                        .getClass()
                        .getEnclosingMethod()
                        .getName())
                .concat("\n")
                .concat(gson.toJson(request)));
        Date date = new Date();
        Optional<KYCDetailModel> model = kycDetailRepository.findById(request.getId());

        if(model.isPresent()) {
            try {
                Timestamp startTime = new Timestamp(dateFormat.parse(dateFormat.format(date)).getTime());
                model.get().setStartTime(startTime);

                Date timeCreated=model.get().getTimeCreated();
                long waitingTime = startTime.getTime()-timeCreated.getTime();
                model.get().setWaitingTime(new BigDecimal(waitingTime));

                return ResponseEntity.ok("");
            } catch (Exception e) {
                logger.error("Message Request Id : ".concat(messageId).concat("\n")
                        .concat(new Object() {
                        }
                                .getClass()
                                .getEnclosingMethod()
                                .getName())
                        .concat("\n")
                        .concat(gson.toJson(e.getMessage())));
                return ResponseEntity.noContent().build();
            }
        } else {
            logger.error("Message Response Id : ".concat(messageId).concat("\n")
                    .concat(new Object() {}
                            .getClass()
                            .getEnclosingMethod()
                            .getName())
                    .concat("\n")
                    .concat(HttpStatus.NOT_FOUND.toString()));
            return ResponseEntity.notFound().build();
        }
    }

    @Override
    public ResponseEntity saveCustomer(KYCDetailRequestModel request) {
        String messageId = UUID.randomUUID().toString();
        logger.error("Message Request Id : ".concat(messageId).concat("\n")
                .concat(new Object() {}
                        .getClass()
                        .getEnclosingMethod()
                        .getName())
                .concat("\n")
                .concat(gson.toJson(request)));

        Date date = new Date();
        Optional<KYCDetailModel> model = kycDetailRepository.findById(request.getId());

        if(model.isPresent()){
            try {
                Timestamp startTime=new Timestamp(dateFormat.parse(dateFormat.format(date)).getTime());
                model.get().setCustomerId(request.getCustomerId());
                model.get().setStartTime(startTime);
                Date timeCreated=model.get().getTimeCreated();

                long waitingTime = startTime.getTime()-timeCreated.getTime();
                model.get().setWaitingTime(new BigDecimal(waitingTime));

                kycDetailRepository.save(model.get());

                return ResponseEntity.ok("");
            } catch (Exception ex){
                logger.error("Message Response Id : ".concat(messageId).concat("\n")
                        .concat(new Object() {}
                                .getClass()
                                .getEnclosingMethod()
                                .getName())
                        .concat("\n")
                        .concat(ex.getMessage()));
                return ResponseEntity.noContent().build();
            }
        } else {
            logger.error("Message Response Id : ".concat(messageId).concat("\n")
                    .concat(new Object() {}
                            .getClass()
                            .getEnclosingMethod()
                            .getName())
                    .concat("\n")
                    .concat(HttpStatus.NOT_FOUND.toString()));

            return ResponseEntity.notFound().build();
        }
    }

    @Override
    public ResponseEntity finish(String guid, KYCDetailRequestModel request) {
        String messageId = UUID.randomUUID().toString();
        logger.error("Message Request Id : ".concat(messageId).concat("\n")
                .concat(new Object() {}
                        .getClass()
                        .getEnclosingMethod()
                        .getName())
                .concat("\n")
                .concat(gson.toJson(request)));

        Date date = new Date();
        Optional<KYCDetailModel> model = kycDetailRepository.findById(guid);

        if(model.isPresent()){
            try {
                model.get().setPathLeft(videoPath);
                model.get().setFileNameLeft(guid+"-agent-merged");
                model.get().setExtLeft("webm");
                model.get().setPathRight(videoPath);
                model.get().setFileNameRight(guid+"-client-merged");
                model.get().setExtRight("webm");
                model.get().setEndTime(new Timestamp(dateFormat.parse(dateFormat.format(date)).getTime()));
                model.get().setKycStatus(request.getKycStatus());
                model.get().setLowestBitrate(new BigDecimal(request.getLowestBitrate()));
                model.get().setHighestBitrate(new BigDecimal(request.getHighestBitrate()));
                model.get().setAvgBitrate(new BigDecimal(request.getAvgBitrate()));
                model.get().setServer(videoIp);

                Date startTime=model.get().getStartTime();
                Date endTime=model.get().getEndTime();
                long duration = endTime.getTime()-startTime.getTime();
                model.get().setDuration(new BigDecimal(duration));

                kycDetailRepository.save(model.get());

                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);

                OpenMediaRequestModel requestModel = new OpenMediaRequestModel();
                requestModel.setGuid(guid);

                HttpEntity httpEntity = new HttpEntity(requestModel, headers);

                String dest = "http://".concat(videoIp).concat(":").concat(videoPort).concat(mergeVideo);
                restTemplate.exchange(dest, HttpMethod.POST, httpEntity, OpenMediaResponseModel.class);

                logger.error("Message Request Id : ".concat(messageId).concat("\n")
                        .concat(new Object() {}
                                .getClass()
                                .getEnclosingMethod()
                                .getName())
                        .concat("\n")
                        .concat(gson.toJson(model.get())));

                return ResponseEntity.ok("");
            } catch (Exception ex){
                logger.error("Message Response Id : ".concat(messageId).concat("\n")
                        .concat(new Object() {}
                                .getClass()
                                .getEnclosingMethod()
                                .getName())
                        .concat("\n")
                        .concat(ex.getMessage()));
                return ResponseEntity.noContent().build();
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    public void RenderVideo(String messageId, String guid) {
        try{
            ProcessBuilder processBuilder = new ProcessBuilder();
            processBuilder.command
                    ("/home/admin/danangkyc/create-video.sh", guid+"-client", guid+"-agent", "/var/www/html/mergedvideo/", guid+"-client-merged", guid+"-agent-merged");

            Process process = processBuilder.start();
            StringBuilder output = new StringBuilder();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
        } catch (IOException ex){
            logger.error("Message Response Id : ".concat(messageId).concat("\n")
                    .concat(new Object() {}
                            .getClass()
                            .getEnclosingMethod()
                            .getName())
                    .concat("\n")
                    .concat(ex.getMessage()));
        }
    }

    @Override
    public ResponseEntity markDone(KYCDetailRequestModel request) {
        String messageId = UUID.randomUUID().toString();
        logger.error("Message Request Id : ".concat(messageId).concat("\n")
                .concat(new Object() {}
                        .getClass()
                        .getEnclosingMethod()
                        .getName())
                .concat("\n")
                .concat(gson.toJson(request)));
        request.getKycNotes();
        Optional<KYCDetailModel> model = kycDetailRepository.findById(request.getId());
        if(model.isPresent()){
            try {
                model.get().setKycNotes(request.getKycNotes());
                model.get().setKycDisposition(request.getKycDisposition());
                kycDetailRepository.save(model.get());

                return ResponseEntity.ok(model.get());
            } catch (Exception ex){
                logger.error("Message Response Id : ".concat(messageId).concat("\n")
                        .concat(new Object() {}
                                .getClass()
                                .getEnclosingMethod()
                                .getName())
                        .concat("\n")
                        .concat(ex.getMessage()));
                return ResponseEntity.noContent().build();
            }
        } else {
            logger.error("Message Response Id : ".concat(messageId).concat("\n")
                    .concat(new Object() {}
                            .getClass()
                            .getEnclosingMethod()
                            .getName())
                    .concat("\n")
                    .concat(HttpStatus.NOT_FOUND.toString()));

            return ResponseEntity.notFound().build();
        }
    }

    @Override
    public ResponseEntity setVideoStatus(KYCDetailRequestModel request) {
        String messageId = UUID.randomUUID().toString();
        logger.error("Message Request Id : ".concat(messageId).concat("\n")
                .concat(new Object() {}
                        .getClass()
                        .getEnclosingMethod()
                        .getName())
                .concat("\n")
                .concat(gson.toJson(request)));
        Optional<KYCDetailModel> model = kycDetailRepository.findById(request.getId());
        if(model.isPresent()){
            try {
                model.get().setKycVideoAvailable(request.getKycVideoAvailable());
                kycDetailRepository.save(model.get());

                return ResponseEntity.ok("");
            } catch (Exception ex){
                logger.error("Message Response Id : ".concat(messageId).concat("\n")
                        .concat(new Object() {}
                                .getClass()
                                .getEnclosingMethod()
                                .getName())
                        .concat("\n")
                        .concat(ex.getMessage()));
                return ResponseEntity.noContent().build();
            }
        } else {
            logger.error("Message Response Id : ".concat(messageId).concat("\n")
                    .concat(new Object() {}
                            .getClass()
                            .getEnclosingMethod()
                            .getName())
                    .concat("\n")
                    .concat(HttpStatus.NOT_FOUND.toString()));

            return ResponseEntity.notFound().build();
        }
    }

    @Override
    public KYCDetailModel agentNotAvailable(KYCDetailRequestModel request) {
        String messageId = UUID.randomUUID().toString();
        logger.error("Message Request Id : ".concat(messageId).concat("\n")
                .concat(new Object() {
                }
                        .getClass()
                        .getEnclosingMethod()
                        .getName())
                .concat("\n")
                .concat(gson.toJson(request)));

        Date date = new Date();
        Optional<KYCDetailModel> model = kycDetailRepository.findById(request.getGuid());
        if (model.isPresent()) {
            try {
                model.get().setEndTime(new Timestamp(dateFormat.parse(dateFormat.format(date)).getTime()));
                model.get().setKycStatus("Agent Not Available");
                return kycDetailRepository.save(model.get());
            } catch (Exception ex) {
                logger.error("Message Response Id : ".concat(messageId).concat("\n")
                        .concat(new Object() {
                        }
                                .getClass()
                                .getEnclosingMethod()
                                .getName())
                        .concat("\n")
                        .concat(ex.getMessage()));
                KYCDetailModel responsefail = new KYCDetailModel();
                responsefail.setKycStatus("EXCEPTION");
                return responsefail;
            }
        }else{
            logger.error("Message Response Id : ".concat(messageId).concat("\n")
                    .concat(new Object() {}
                            .getClass()
                            .getEnclosingMethod()
                            .getName())
                    .concat("\n")
                    .concat(HttpStatus.NOT_FOUND.toString()));
            KYCDetailModel responsefail = new KYCDetailModel();
            responsefail.setKycStatus("not found");
            return responsefail;
        }
    }

    @Override
    public KYCDetailModel rejectedByCustomer(KYCDetailRequestModel request) {
        String messageId = UUID.randomUUID().toString();
        logger.error("Message Request Id : ".concat(messageId).concat("\n")
                .concat(new Object() {
                }
                        .getClass()
                        .getEnclosingMethod()
                        .getName())
                .concat("\n")
                .concat(gson.toJson(request)));

        Date date = new Date();
        Optional<KYCDetailModel> model = kycDetailRepository.findById(request.getGuid());

        if (model.isPresent()) {
            try {
                model.get().setEndTime(new Timestamp(dateFormat.parse(dateFormat.format(date)).getTime()));
                model.get().setKycStatus("Rejected By Customer");
                return kycDetailRepository.save(model.get());
            } catch (Exception ex) {
                logger.error("Message Response Id : ".concat(messageId).concat("\n")
                        .concat(new Object() {
                        }
                                .getClass()
                                .getEnclosingMethod()
                                .getName())
                        .concat("\n")
                        .concat(ex.getMessage()));
                KYCDetailModel response = new KYCDetailModel();
                response.setKycStatus("ERROR");
                return response;
            }
        } else {
            logger.error("Message Response Id : ".concat(messageId).concat("\n")
                    .concat(new Object() {
                    }
                            .getClass()
                            .getEnclosingMethod()
                            .getName())
                    .concat("\n")
                    .concat(HttpStatus.NOT_FOUND.toString()));
            KYCDetailModel response = new KYCDetailModel();
            response.setKycStatus("ERROR");
            return response;
        }
    }
}
