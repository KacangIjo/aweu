package com.example.videokycapi.model;

import java.io.Serializable;

public class CustomerResponseModel implements Serializable {

    private String responseCode;
    private CustomerModel user;

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public CustomerModel getUser() {
        return user;
    }

    public void setUser(CustomerModel user) {
        this.user = user;
    }
}
