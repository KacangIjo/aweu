package com.example.videokycapi.model;

import java.io.Serializable;

public class RequestModel implements Serializable {

    private String functionName;
    private ParameterModel parameters;

    public String getFunctionName() {
        return functionName;
    }

    public void setFunctionName(String functionName) {
        this.functionName = functionName;
    }

    public ParameterModel getParameters() {
        return parameters;
    }

    public void setParameters(ParameterModel parameters) {
        this.parameters = parameters;
    }
}
