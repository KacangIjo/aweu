package com.example.videokycapi.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.persistence.Column;

public class KYCDetailRequestModel {
    private String id;
    private String guid;
    private String agentId;
    private String dbId;
    private String agentGroup;
    private String customerId;
    private String interactionId;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private String startTime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private String endTime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private String duration;
    private String server;
    private String pathLeft;
    private String fileNameLeft;
    private String extLeft;
    private String pathRight;
    private String fileNameRight;
    private String extRight;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private String timeCreated;
    private String createdBy;
    private String channel;
    private String version;
    private String kycName;
    private String kycTelp;
    private String kycEmail;
    private String kycNotes;
    private String kycStatus;
    private String isAbandon;
    private String waitingTime;
    private String lowestBitrate;
    private String HighestBitrate;
    private String avgBitrate;
    private String kycDisposition;
    private String kycVideoAvailable;

    public String getKycDisposition() { return kycDisposition; }
    public void setKycDisposition(String kycDisposition) { this.kycDisposition = kycDisposition; }

    public String getKycVideoAvailable() { return kycVideoAvailable; }
    public void setKycVideoAvailable(String kycVideoAvailable) { this.kycVideoAvailable = kycVideoAvailable; }

    public String getAgentId() {
        return agentId;
    }
    public void setAgentId(String agentId) {
        this.agentId = agentId;
    }

    public String getGuid() { return guid; }
    public void setGuid(String guid) { this.guid = guid; }

    public String getDbId() {
        return dbId;
    }
    public void setDbId(String dbId) {
        this.dbId = dbId;
    }

    public String getAgentGroup() {
        return agentGroup;
    }

    public void setAgentGroup(String agentGroup) {
        this.agentGroup = agentGroup;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getInteractionId() {
        return interactionId;
    }

    public void setInteractionId(String interactionId) {
        this.interactionId = interactionId;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    public String getPathLeft() {
        return pathLeft;
    }

    public void setPathLeft(String pathLeft) {
        this.pathLeft = pathLeft;
    }

    public String getFileNameLeft() {
        return fileNameLeft;
    }

    public void setFileNameLeft(String fileNameLeft) {
        this.fileNameLeft = fileNameLeft;
    }

    public String getExtLeft() {
        return extLeft;
    }

    public void setExtLeft(String extLeft) {
        this.extLeft = extLeft;
    }

    public String getPathRight() {
        return pathRight;
    }

    public void setPathRight(String pathRight) {
        this.pathRight = pathRight;
    }

    public String getFileNameRight() {
        return fileNameRight;
    }

    public void setFileNameRight(String fileNameRight) {
        this.fileNameRight = fileNameRight;
    }

    public String getExtRight() {
        return extRight;
    }

    public void setExtRight(String extRight) {
        this.extRight = extRight;
    }

    public String getTimeCreated() {
        return timeCreated;
    }

    public void setTimeCreated(String timeCreated) {
        this.timeCreated = timeCreated;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getKycName() {
        return kycName;
    }

    public void setKycName(String kycName) {
        this.kycName = kycName;
    }

    public String getKycTelp() {
        return kycTelp;
    }

    public void setKycTelp(String kycTelp) {
        this.kycTelp = kycTelp;
    }

    public String getKycEmail() {
        return kycEmail;
    }

    public void setKycEmail(String kycEmail) {
        this.kycEmail = kycEmail;
    }

    public String getKycNotes() {
        return kycNotes;
    }
    public void setKycNotes(String kycNotes) {
        this.kycNotes = kycNotes;
    }

    public String getKycStatus() {
        return kycStatus;
    }
    public void setKycStatus(String kycStatus) {
        this.kycStatus = kycStatus;
    }

    public String getIsAbandon() {
        return isAbandon;
    }
    public void setIsAbandon(String isAbandon) {
        this.isAbandon = isAbandon;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getWaitingTime() { return waitingTime; }
    public void setWaitingTime(String waitingTime) { this.waitingTime = waitingTime; }

    public String getLowestBitrate() { return lowestBitrate; }
    public void setLowestBitrate(String lowestBitrate) { this.lowestBitrate = lowestBitrate; }

    public String getHighestBitrate() { return HighestBitrate; }
    public void setHighestBitrate(String highestBitrate) { HighestBitrate = highestBitrate; }

    public String getAvgBitrate() { return avgBitrate; }
    public void setAvgBitrate(String avgBitrate) { this.avgBitrate = avgBitrate; }
}
