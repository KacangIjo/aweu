package com.example.videokycapi.service.impl;

import com.example.videokycapi.model.*;
import com.example.videokycapi.service.ICustomerService;
import com.google.gson.Gson;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Objects;
import java.util.UUID;

@Service
public class CustomerService implements ICustomerService {

    @Value("${base.serviceomniurl}")
    private String serviceOmni;

    Logger logger= LogManager.getLogger(CustomerService.class);
    Gson gson = new Gson();

    @Override
    public ResponseEntity<CustomerResponseFinalModel> getCustomerData(CustomerRequestModel customerRequestModel) {
        String messageId = UUID.randomUUID().toString();
        CustomerResponseFinalModel customerResponseFinalModel=new CustomerResponseFinalModel();
        CustomerFinalModel customerFinalModel=new CustomerFinalModel();
        logger.error("Message Request Id : ".concat(messageId).concat("\n")
                .concat(new Object() {}
                        .getClass()
                        .getEnclosingMethod()
                        .getName())
                .concat("\n")
                .concat(gson.toJson(customerRequestModel)));

        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        ParameterModel parameterModel = new ParameterModel();
        parameterModel.setCif(customerRequestModel.getUserNik());
        //parameterModel.setInteractionId(customerRequestModel.getMessageGuid());

        RequestModel requestModel = new RequestModel();
        requestModel.setFunctionName("14003");
        requestModel.setParameters(parameterModel);

        HttpEntity request = new HttpEntity(requestModel, headers);

        ResponseEntity<GlobalModel> response = restTemplate.exchange(serviceOmni, HttpMethod.POST, request, GlobalModel.class);

        if(response.getStatusCode() == HttpStatus.OK){
            logger.error("Message Omni Response Id : ".concat(messageId).concat("\n")
                    .concat(new Object() {}
                            .getClass()
                            .getEnclosingMethod()
                            .getName())
                    .concat("\n")
                    .concat(gson.toJson(Objects.requireNonNull(response.getBody()).getResponseObject())));

            CustomerResponseModel customerResponseModel = gson.fromJson(gson.toJsonTree(Objects.requireNonNull(response.getBody()).getResponseObject()), CustomerResponseModel.class);

            if(Objects.nonNull(customerResponseModel)){
                logger.error("Message Response Id : ".concat(messageId).concat("\n")
                        .concat(new Object() {}
                                .getClass()
                                .getEnclosingMethod()
                                .getName())
                        .concat("\n")
                        .concat(gson.toJson(Objects.requireNonNull(response.getBody()).getResponseObject())));

                customerFinalModel.setCifNumber(customerResponseModel.getUser().getCif());
                customerFinalModel.setNamaNasabah(customerResponseModel.getUser().getUserName());
                customerFinalModel.setEmailAddress(customerResponseModel.getUser().getEmail());
                customerFinalModel.setPhoneNumber(customerResponseModel.getUser().getDeviceNumber());
                customerResponseFinalModel.setData(customerFinalModel);

                return ResponseEntity.ok(customerResponseFinalModel);
            } else {
                logger.error("Message Response Id : ".concat(messageId).concat("\n")
                        .concat(new Object() {}
                                .getClass()
                                .getEnclosingMethod()
                                .getName())
                        .concat("\n")
                        .concat("Customer Null"));

                return ResponseEntity.ok(customerResponseFinalModel);
            }
        } else {
            logger.error("Message Response Id : ".concat(messageId).concat("\n")
                    .concat(new Object() {}
                            .getClass()
                            .getEnclosingMethod()
                            .getName())
                    .concat("\n")
                    .concat(response.getStatusCode().toString()));

            return ResponseEntity.ok(customerResponseFinalModel);
        }
    }
}
