package com.example.videokycapi;

import com.example.videokycapi.utility.RSAKeyPair;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.security.KeyPair;

@SpringBootApplication
@EnableAutoConfiguration
public class DemoApplication {

	public static KeyPair keypair = RSAKeyPair.keyPairRSA();

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate() {
		RestTemplate restTemplate = new RestTemplate();
		((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setConnectTimeout(300000);
		((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setReadTimeout(300000);

		return restTemplate;
	}
}
