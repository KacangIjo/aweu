package com.example.videokycapi.service.impl;

import com.example.videokycapi.controller.OpenMediaController;
import com.example.videokycapi.model.*;
import com.example.videokycapi.repository.KYCDetailRepository;
import com.example.videokycapi.service.IOpenMediaService;
import com.google.gson.Gson;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;
import java.util.UUID;

@Service
public class OpenMediaService implements IOpenMediaService {

    @Value("${openmedia.url}")
    String urlOpenMedia;

    @Value("${openmedia.secret}")
    String openMediaSecret;

    @Value("${openmedia.timeout}")
    String openMediaTimeout;

    @Value("${base.serviceomniurl}")
    private String serviceOmni;

    @Autowired
    public KYCDetailRepository kycDetailRepository;

    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    Logger logger= LogManager.getLogger(OpenMediaController.class);
    Gson gson = new Gson();

    @Override
    public String callOpenMedia(OpenMediaRequestModel openMediaRequestModel){
        String messageId = UUID.randomUUID().toString();
        logger.error("Message Request Id : ".concat(messageId).concat("\n")
                .concat(new Object() {}
                        .getClass()
                        .getEnclosingMethod()
                        .getName())
                .concat("\n")
                .concat(gson.toJson(openMediaRequestModel)));

        try {
            KYCDetailModel model = getCustomerData(messageId, openMediaRequestModel.getCif());

            Date date = new Date();
            model.setId(openMediaRequestModel.getGuid());
            model.setCustomerId(openMediaRequestModel.getCif());
            model.setTimeCreated(new Timestamp(dateFormat.parse(dateFormat.format(date)).getTime()));
            model.setChannel(openMediaRequestModel.getChannel());
            model.setKycStatus("Drop By Customer");
            kycDetailRepository.save(model);

            String plainCreds = openMediaSecret;
            byte[] plainCredsBytes = plainCreds.getBytes();
            byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
            String base64Creds = new String(base64CredsBytes);

            HttpHeaders headers = new HttpHeaders();
            headers.add("Authorization", "Basic " + base64Creds);
            headers.add("Access-Control-Allow-Origin", "*");
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

            MultiValueMap<String, String> map= new LinkedMultiValueMap<String, String>();
            map.add("userData[CIF]", openMediaRequestModel.getCif());
            map.add("userData[FirstName]", model.getKycName());
            map.add("userData[PhoneNumber]", model.getKycTelp());
            map.add("userData[guid]", openMediaRequestModel.getGuid());
            map.add("userData[Email]", model.getKycEmail());
            map.add("userData[channel]", openMediaRequestModel.getChannel());
            map.add("userData[timeout]", openMediaTimeout);

            RestTemplate restTemplate=new RestTemplate();
            HttpEntity request = new HttpEntity(map, headers);
            ResponseEntity<OpenMediaResponseModel> response = restTemplate.exchange(urlOpenMedia, HttpMethod.POST, request, OpenMediaResponseModel.class);

            if(response.getStatusCode() == HttpStatus.OK) {
                logger.error("Message Response Id : ".concat(messageId).concat("\n")
                        .concat(new Object() {}
                                .getClass()
                                .getEnclosingMethod()
                                .getName())
                        .concat("\n")
                        .concat(Objects.requireNonNull(response.getBody()).getInteractionId()));
                return Objects.requireNonNull(response.getBody()).getInteractionId();
            } else {
                logger.error("Message Response Id : ".concat(messageId).concat("\n")
                        .concat(new Object() {}
                                .getClass()
                                .getEnclosingMethod()
                                .getName())
                        .concat("\n")
                        .concat(String.valueOf(response.getStatusCode())));
                return "ERROR";
            }
        }catch(Exception e){
            logger.error("Message Request Id : ".concat(messageId).concat("\n")
                    .concat(new Object() {}
                            .getClass()
                            .getEnclosingMethod()
                            .getName())
                    .concat("\n")
                    .concat(gson.toJson(e.getMessage())));
            return "ERROR";
        }
    }

    @Override
    public void closeOpenMedia(String interactionId) {
        String messageId = UUID.randomUUID().toString();
        logger.error("Message Request Id : ".concat(messageId).concat("\n")
                .concat(new Object() {}
                        .getClass()
                        .getEnclosingMethod()
                        .getName())
                .concat("\n")
                .concat(interactionId));

        HttpHeaders headers = new HttpHeaders();
        headers.add("Access-Control-Allow-Origin", "*");
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        final String Uri = urlOpenMedia + "/" + interactionId + "/stop";
        MultiValueMap<String, String> map= new LinkedMultiValueMap<String, String>();
        HttpEntity request = new HttpEntity(map,headers);
        RestTemplate restTemplate=new RestTemplate();
        ResponseEntity<OpenMediaResponseModel> response = restTemplate.exchange(Uri, HttpMethod.POST, request, OpenMediaResponseModel.class);

        logger.error("Message Response Id : ".concat(messageId).concat("\n")
                .concat(new Object() {}
                        .getClass()
                        .getEnclosingMethod()
                        .getName())
                .concat("\n")
                .concat(response.getStatusCode() + " " + gson.toJson(response.getBody())));
    }

    @Override
    public KYCDetailModel getCustomerData(String messageId, String cif) {
        KYCDetailModel model = new KYCDetailModel();
        RestTemplate restTemplateOmni = new RestTemplate();

        HttpHeaders headersOmni = new HttpHeaders();
        headersOmni.setContentType(MediaType.APPLICATION_JSON);
        ParameterModel parameterModel = new ParameterModel();
        parameterModel.setCif(cif);
        //parameterModel.setInteractionId(customerRequestModel.getMessageGuid());

        RequestModel requestModel = new RequestModel();
        requestModel.setFunctionName("14003");
        requestModel.setParameters(parameterModel);

        HttpEntity requestOmni = new HttpEntity(requestModel, headersOmni);

        ResponseEntity<GlobalModel> responseOmni = restTemplateOmni.exchange(serviceOmni, HttpMethod.POST, requestOmni, GlobalModel.class);

        CustomerResponseModel customerResponseModel = gson.fromJson(gson.toJsonTree(Objects.requireNonNull(responseOmni.getBody()).getResponseObject()), CustomerResponseModel.class);
        if(Objects.nonNull(customerResponseModel)) {
            logger.error("Message Response Id : ".concat(messageId).concat("\n")
                    .concat(new Object() {
                    }
                            .getClass()
                            .getEnclosingMethod()
                            .getName())
                    .concat("\n")
                    .concat(gson.toJson(Objects.requireNonNull(responseOmni.getBody()).getResponseObject())));
            model.setKycEmail(customerResponseModel.getUser().getEmail());
            model.setKycName(customerResponseModel.getUser().getUserName());
            model.setKycTelp(customerResponseModel.getUser().getDeviceNumber());
        }

        return model;
    }
}
