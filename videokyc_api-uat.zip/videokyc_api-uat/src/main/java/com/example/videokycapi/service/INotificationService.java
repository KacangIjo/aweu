package com.example.videokycapi.service;

import com.example.videokycapi.model.KYCDetailRequestModel;
import org.springframework.http.ResponseEntity;

public interface INotificationService {

    String sendNotification(KYCDetailRequestModel request);
    ResponseEntity sendTimeOutNotification(KYCDetailRequestModel request);
}
