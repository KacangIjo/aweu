package com.example.videokycapi.controller;

import com.example.videokycapi.model.CustomerRequestModel;
import com.example.videokycapi.model.CustomerResponseFinalModel;
import com.example.videokycapi.service.ICustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@RestController
public class CustomerController {

    @Autowired
    private ICustomerService customerService;

    @PostMapping("/customer/data")
    public ResponseEntity<CustomerResponseFinalModel> getCustomerData(@Valid @RequestBody CustomerRequestModel openMediaRequestModel, HttpSession session) {
        return customerService.getCustomerData(openMediaRequestModel);
    }
}
