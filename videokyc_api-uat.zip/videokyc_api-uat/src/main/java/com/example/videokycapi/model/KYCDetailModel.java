package com.example.videokycapi.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Entity
@Table(name = "TBL_BO_VID_REC", schema = "IBANKBO")
public class KYCDetailModel {

    @Id
    @Column(name = "GUID")
    private String id;

    @Column(name = "AGENT_ID")
    private String agentId;

    @Column(name = "DB_ID")
    private String dbId;

    @Column(name = "AGENT_GROUP")
    private String agentGroup;

    @Column(name = "TRX_ID")
    private String customerId;

    @Column(name = "INTERACTION_ID")
    private String interactionId;

    @Column(name = "START_TIME")
    private Timestamp startTime;

    @Column(name = "END_TIME")
    private Timestamp endTime;

    @Column(name = "DURATION")
    private BigDecimal duration;

    @Column(name = "IP_SERVER")
    private String server;

    @Column(name = "VID_PATH_LEFT")
    private String pathLeft;

    @Column(name = "FILE_NAME_LEFT")
    private String fileNameLeft;

    @Column(name = "FILE_EXT_LEFT")
    private String extLeft;

    @Column(name = "VID_PATH_RIGHT")
    private String pathRight;

    @Column(name = "FILE_NAME_RIGHT")
    private String fileNameRight;

    @Column(name = "FILE_EXT_RIGHT")
    private String extRight;

    @Column(name = "TIME_CREATED")
    private Timestamp timeCreated;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CHANNEL")
    private String channel;

    @Column(name = "VERSION")
    private int version;

    @Column(name = "KYC_NAME")
    private String kycName;

    @Column(name = "KYC_TELP")
    private String kycTelp;

    @Column(name = "KYC_EMAIL")
    private String kycEmail;

    @Column(name = "KYC_NOTES")
    private String kycNotes;

    @Column(name = "KYC_STATUS")
    private String kycStatus;

    @Column(name = "IS_ABANDON")
    private String isAbandon;

    @Column(name = "WAITING_TIME")
    private BigDecimal waitingTime;

    @Column(name = "LOWEST_BITRATE")
    private BigDecimal lowestBitrate;

    @Column(name = "HIGHEST_BITRATE")
    private BigDecimal highestBitrate;

    @Column(name = "AVG_BITRATE")
    private BigDecimal avgBitrate;

    @Column(name = "KYC_DISPOSITION")
    private String kycDisposition;

    @Column(name = "KYC_VIDEOAVAILABLE")
    private String kycVideoAvailable;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getAgentId() { return agentId; }
    public void setAgentId(String agentId) { this.agentId = agentId; }

    public String getDbId() { return dbId; }
    public void setDbId(String dbId) { this.dbId = dbId; }

    public String getAgentGroup() { return agentGroup; }
    public void setAgentGroup(String agentGroup) { this.agentGroup = agentGroup; }

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }

    public Timestamp getStartTime() { return startTime; }
    public void setStartTime(Timestamp startTime) { this.startTime = startTime; }

    public Timestamp getEndTime() { return endTime; }
    public void setEndTime(Timestamp endTime) { this.endTime = endTime; }

    public BigDecimal getDuration() { return duration; }
    public void setDuration(BigDecimal duration) { this.duration = duration; }

    public String getServer() { return server; }
    public void setServer(String server) { this.server = server; }

    public String getChannel() { return channel; }
    public void setChannel(String channel) { this.channel = channel; }

    public String getPathLeft() { return pathLeft; }
    public void setPathLeft(String pathLeft) { this.pathLeft = pathLeft; }

    public String getFileNameLeft() { return fileNameLeft; }
    public void setFileNameLeft(String fileNameLeft) { this.fileNameLeft = fileNameLeft; }

    public String getExtLeft() { return extLeft; }
    public void setExtLeft(String extLeft) { this.extLeft = extLeft; }

    public String getPathRight() { return pathRight; }
    public void setPathRight(String pathRight) { this.pathRight = pathRight; }

    public String getFileNameRight() { return fileNameRight; }
    public void setFileNameRight(String fileNameRight) { this.fileNameRight = fileNameRight; }

    public String getExtRight() { return extRight; }
    public void setExtRight(String extRight) { this.extRight = extRight; }

    public Timestamp getTimeCreated() { return timeCreated; }
    public void setTimeCreated(Timestamp timeCreated) { this.timeCreated = timeCreated; }

    public String getCreatedBy() { return createdBy; }
    public void setCreatedBy(String createdBy) { this.createdBy = createdBy; }

    public int getVersion() { return version; }
    public void setVersion(int version) { this.version = version; }

    public String getInteractionId() { return interactionId; }
    public void setInteractionId(String interactionId) { this.interactionId = interactionId; }

    public String getKycName() { return kycName; }
    public void setKycName(String kycName) { this.kycName = kycName; }

    public String getKycTelp() { return kycTelp; }
    public void setKycTelp(String kycTelp) { this.kycTelp = kycTelp; }

    public String getKycEmail() { return kycEmail; }
    public void setKycEmail(String kycEmail) { this.kycEmail = kycEmail; }

    public String getKycNotes() { return kycNotes; }
    public void setKycNotes(String kycNotes) { this.kycNotes = kycNotes; }

    public String getKycStatus() { return kycStatus; }
    public void setKycStatus(String kycStatus) { this.kycStatus = kycStatus; }

    public String getIsAbandon() { return isAbandon; }
    public void setIsAbandon(String isAbandon) { this.isAbandon = isAbandon; }

    public BigDecimal getWaitingTime() { return waitingTime; }
    public void setWaitingTime(BigDecimal waitingTime) { this.waitingTime = waitingTime; }

    public BigDecimal getLowestBitrate() { return lowestBitrate; }
    public void setLowestBitrate(BigDecimal lowestBitrate) { this.lowestBitrate = lowestBitrate; }

    public BigDecimal getHighestBitrate() { return highestBitrate; }
    public void setHighestBitrate(BigDecimal highestBitrate) { this.highestBitrate = highestBitrate; }

    public BigDecimal getAvgBitrate() { return avgBitrate; }
    public void setAvgBitrate(BigDecimal avgBitrate) { this.avgBitrate = avgBitrate; }

    public String getKycDisposition() { return kycDisposition; }

    public void setKycDisposition(String kycDisposition) { this.kycDisposition = kycDisposition; }

    public String getKycVideoAvailable() {
        return kycVideoAvailable;
    }

    public void setKycVideoAvailable(String kycVideoAvailable) {
        this.kycVideoAvailable = kycVideoAvailable;
    }
}
