package com.example.videokycapi.model;

public class OpenMediaRequestModel {
    private String guid;
    private String cif;
    private String channel;
    private String kycName;
    private String kycTelp;
    private String kycEmail;

    public String getGuid() {
        return guid;
    }
    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getCif() {
        return cif;
    }
    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getChannel() {
        return channel;
    }
    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getKycName() { return kycName; }
    public void setKycName(String kycName) { this.kycName = kycName; }

    public String getKycTelp() {
        return kycTelp;
    }
    public void setKycTelp(String kycTelp) {
        this.kycTelp = kycTelp;
    }

    public String getKycEmail() {
        return kycEmail;
    }
    public void setKycEmail(String kycEmail) {
        this.kycEmail = kycEmail;
    }
}
