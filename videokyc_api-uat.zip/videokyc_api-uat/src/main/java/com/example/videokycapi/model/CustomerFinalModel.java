package com.example.videokycapi.model;

import java.io.Serializable;

public class CustomerFinalModel implements Serializable {


    private String cifNumber;
    private String namaNasabah;
    private String jenisKelamin;
    private String jenisNasabah;
    private boolean businessBankingFlag;
    private boolean wni;
    private String segment;
    private String nikrm;
    private String rmPhoneNumber;
    private String emailAddress;
    private String phoneNumber;

    public CustomerFinalModel() {
        jenisKelamin="";
        jenisNasabah="";
        businessBankingFlag=false;
        wni=false;
        segment="";
        nikrm="";
        rmPhoneNumber="";
    }

    public String getCifNumber() {
        return cifNumber;
    }

    public void setCifNumber(String cifNumber) {
        this.cifNumber = cifNumber;
    }

    public String getNamaNasabah() {
        return namaNasabah;
    }

    public void setNamaNasabah(String namaNasabah) {
        this.namaNasabah = namaNasabah;
    }

    public String getJenisKelamin() {
        return jenisKelamin;
    }

    public void setJenisKelamin(String jenisKelamin) {
        this.jenisKelamin = jenisKelamin;
    }

    public String getJenisNasabah() {
        return jenisNasabah;
    }

    public void setJenisNasabah(String jenisNasabah) {
        this.jenisNasabah = jenisNasabah;
    }

    public boolean getBusinessBankingFlag() {
        return businessBankingFlag;
    }

    public void setBusinessBankingFlag(boolean businessBankingFlag) {
        this.businessBankingFlag = businessBankingFlag;
    }

    public boolean getWni() {
        return wni;
    }

    public void setWni(boolean wni) {
        this.wni = wni;
    }

    public String getSegment() {
        return segment;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public String getNikrm() {
        return nikrm;
    }

    public void setNikrm(String nikrm) {
        this.nikrm = nikrm;
    }

    public String getRmPhoneNumber() {
        return rmPhoneNumber;
    }

    public void setRmPhoneNumber(String rmPhoneNumber) {
        this.rmPhoneNumber = rmPhoneNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
