package com.example.videokycapi.repository;

import com.example.videokycapi.model.KYCDetailModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface KYCDetailRepository extends JpaRepository<KYCDetailModel, Long>{

    Optional<KYCDetailModel> findById(String guid);

    Optional<KYCDetailModel> findByCustomerIdAndInteractionId(String customerId, String interactionId);

    @Query(value = "DELETE FROM IBANKBO.TBL_BO_VID_REC WHERE GUID = ?1", nativeQuery = true)
    KYCDetailModel deleteByGuid(String guid);

    @Query(value = "SELECT * FROM IBANKBO.TBL_BO_VID_REC WHERE GUID = ?1", nativeQuery = true)
    KYCDetailModel findByGuid(String guid);
}
