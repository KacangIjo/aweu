package com.example.videokycapi.controller;

import com.example.videokycapi.model.KYCDetailRequestModel;
import com.example.videokycapi.service.INotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import javax.validation.Valid;

public class NotificationController {

    @Autowired
    private INotificationService notificationService;

    @PostMapping("/notifications")
    public String sendNotification(@Valid @RequestBody KYCDetailRequestModel request) {
        return notificationService.sendNotification(request);
    }

    @PostMapping("/notifications/timeout")
    public ResponseEntity sendTimeOutNotification(@Valid @RequestBody KYCDetailRequestModel request) {
        return notificationService.sendTimeOutNotification(request);
    }
}
