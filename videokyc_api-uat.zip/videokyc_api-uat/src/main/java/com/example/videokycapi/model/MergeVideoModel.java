package com.example.videokycapi.model;

public class MergeVideoModel {
    private String sourceClient;
    private String sourceAgent;
    private String destinationClient;
    private String destinationAgent;

    public MergeVideoModel() {
    }

    public String getSourceClient() {
        return sourceClient;
    }

    public void setSourceClient(String sourceClient) {
        this.sourceClient = sourceClient;
    }

    public String getSourceAgent() {
        return sourceAgent;
    }

    public void setSourceAgent(String sourceAgent) {
        this.sourceAgent = sourceAgent;
    }

    public String getDestinationClient() {
        return destinationClient;
    }

    public void setDestinationClient(String destinationClient) {
        this.destinationClient = destinationClient;
    }

    public String getDestinationAgent() {
        return destinationAgent;
    }

    public void setDestinationAgent(String destinationAgent) {
        this.destinationAgent = destinationAgent;
    }
}
