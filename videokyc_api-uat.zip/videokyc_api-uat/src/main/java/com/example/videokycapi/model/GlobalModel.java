package com.example.videokycapi.model;

import com.google.gson.internal.LinkedTreeMap;

import java.io.Serializable;
import java.util.Date;

public class GlobalModel implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -1509458548700846946L;
    private String functionName;
    private LinkedTreeMap<?, ?> parameters;
    private Object responseObject;
    private String status;
    private String errorCode;
    private String errorDesc;
    private String requestTime;
    private String responseTime;

    public String getFunctionName() {
        return functionName;
    }

    public void setFunctionName(String functionName) {
        this.functionName = functionName;
    }

    public String getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(String requestTime) {
        this.requestTime = requestTime;
    }

    public String getResponseTime() {
        return responseTime;
    }

    public void setResponseTime(String responseTime) {
        this.responseTime = responseTime;
    }

    public LinkedTreeMap<?, ?> getParameters() {
        return parameters;
    }

    public void setParameters(LinkedTreeMap<?, ?> parameters) {
        this.parameters = parameters;
    }

    public Object getResponseObject() {
        return responseObject;
    }

    public void setResponseObject(Object responseObject) {
        this.responseObject = responseObject;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorDesc() {
        return errorDesc;
    }

    public void setErrorDesc(String errorDesc) {
        this.errorDesc = errorDesc;
    }
}
