package com.example.videokycapi.controller;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.UUID;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import com.example.videokycapi.utility.RSAUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EncryptionController {
	Logger logger = LogManager.getLogger(EncryptionController.class);

   	@RequestMapping("/v1/encrypt/{plainText}")
   	public String encrypt(@PathVariable String plainText) throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException, NoSuchPaddingException, UnsupportedEncodingException{
	   	String messageId = UUID.randomUUID().toString();
	   	logger.error("Message Request Id : ".concat(messageId).concat("\n")
			   .concat(new Object() {}
					   .getClass()
					   .getEnclosingMethod()
					   .getName())
			   .concat("\n")
			   .concat(plainText));
	   	String encryptedString = null;
	   	try {
	   		encryptedString = Base64.getEncoder().encodeToString(RSAUtil.encrypt(plainText, RSAUtil.publicKey));
	   	} catch (NoSuchAlgorithmException ex) {
		   	logger.error("Message Response Id : ".concat(messageId).concat("\n")
				   .concat(new Object() {}
						   .getClass()
						   .getEnclosingMethod()
						   .getName())
				   .concat("\n")
				   .concat(ex.getMessage()));
	   	}
	   	return encryptedString;
   	}

   	@RequestMapping("/v1/decrypt")
   	public String decrypt(@RequestParam("encryptedString") String encryptedString) throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException, NoSuchPaddingException {
	   	String messageId = UUID.randomUUID().toString();
	   	logger.error("Message Request Id : ".concat(messageId).concat("\n")
			   .concat(new Object() {}
					   .getClass()
					   .getEnclosingMethod()
					   .getName())
			   .concat("\n")
			   .concat(encryptedString));
		String decryptedString = null;
	   	try {
	   		encryptedString = encryptedString.replace(" ", "+");
			decryptedString = RSAUtil.decrypt(encryptedString, RSAUtil.privateKey);
			logger.error("Message Response Id : ".concat(messageId).concat("\n")
					.concat(new Object() {}
							.getClass()
							.getEnclosingMethod()
							.getName())
					.concat("\n")
					.concat(decryptedString));
		} catch (NoSuchAlgorithmException ex) {
			logger.error("Message Response Id : ".concat(messageId).concat("\n")
					.concat(new Object() {}
							.getClass()
							.getEnclosingMethod()
							.getName())
					.concat("\n")
					.concat(ex.getMessage()));
		}
	   return decryptedString;
	}
}
