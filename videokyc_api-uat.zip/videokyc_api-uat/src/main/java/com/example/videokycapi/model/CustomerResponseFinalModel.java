package com.example.videokycapi.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class CustomerResponseFinalModel implements Serializable {

    private CustomerFinalModel data;

    public CustomerFinalModel getData() {
        return data;
    }
    public void setData(CustomerFinalModel data) {
        this.data = data;
    }

}
