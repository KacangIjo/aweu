package com.example.videokycapi.service;

import com.example.videokycapi.model.KYCDetailModel;
import com.example.videokycapi.model.KYCDetailRequestModel;
import org.springframework.http.ResponseEntity;

import java.text.ParseException;
import java.util.List;

public interface IKycDetailService {

    List<KYCDetailModel> getAllRecordDetail();

    KYCDetailModel save(String generatedGuid, KYCDetailRequestModel request);

    ResponseEntity saveByAgent(KYCDetailRequestModel request);

    ResponseEntity saveCustomer(KYCDetailRequestModel request);

    ResponseEntity finish(String guid, KYCDetailRequestModel request);

    ResponseEntity markDone(KYCDetailRequestModel request);

    ResponseEntity setVideoStatus(KYCDetailRequestModel request);

    KYCDetailModel agentNotAvailable(KYCDetailRequestModel request);

    KYCDetailModel rejectedByCustomer(KYCDetailRequestModel request);


}
