package com.example.videokycapi.controller;

import java.util.UUID;

import com.example.videokycapi.service.IOpenMediaService;
import com.example.videokycapi.model.OpenMediaRequestModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.annotation.SessionScope;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@SessionScope
@RestController
public class OpenMediaController {

    @Autowired
    private IOpenMediaService openMediaService;

    @GetMapping("/getGuid")
    public String getGuid() {
        return UUID.randomUUID().toString();
    }

    @PostMapping("/CloseMedia/{InteractionId}")
    public void CloseMediaSession(@PathVariable(value = "InteractionId") String interactionId) {
        openMediaService.closeOpenMedia(interactionId);
    }

    @PostMapping("/OpenMedia")
    public String OpenMedia(@Valid @RequestBody OpenMediaRequestModel openMediaRequestModel, HttpSession session) {
        return openMediaService.callOpenMedia(openMediaRequestModel);
    }
}

