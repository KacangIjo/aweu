package com.example.videokycapi.service;

import com.example.videokycapi.model.CustomerRequestModel;
import com.example.videokycapi.model.CustomerResponseFinalModel;
import org.springframework.http.ResponseEntity;

public interface ICustomerService {

    ResponseEntity<CustomerResponseFinalModel> getCustomerData(CustomerRequestModel customerRequestModel);
}
