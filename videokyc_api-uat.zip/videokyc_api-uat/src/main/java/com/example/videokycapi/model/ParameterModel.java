package com.example.videokycapi.model;

import java.io.Serializable;

public class ParameterModel implements Serializable {

    private String cif;
    //private String interactionId;

    public String getCif() { return cif; }
    public void setCif(String cif) {
        this.cif = cif;
    }

//    public String getInteractionId() { return interactionId; }
//    public void setInteractionId(String interactionId) { this.interactionId = interactionId; }

}
