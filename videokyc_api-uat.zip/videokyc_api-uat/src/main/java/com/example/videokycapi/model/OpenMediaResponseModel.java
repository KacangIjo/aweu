package com.example.videokycapi.model;

public class OpenMediaResponseModel {
    private String statusCode;
    private String interactionId;

    public String getStatusCode() {
        return statusCode;
    }

    public String getInteractionId() {
        return interactionId;
    }
}
