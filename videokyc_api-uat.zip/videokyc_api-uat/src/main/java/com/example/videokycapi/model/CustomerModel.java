package com.example.videokycapi.model;

import java.io.Serializable;

public class CustomerModel implements Serializable {


    private String userId;
    private String userCode;
    private String nickname;
    private String userName;
    private String dateOfBirth;
    private String cif;
    private String email;
    private String deviceNumber;

    public String getUserId() {
        return userId;
    }
    public void setUserId(String userId) { this.userId = userId; }

    public String getUserCode() { return userCode; }
    public void setUserCode(String userCode) { this.userCode = userCode; }

    public String getNickname() { return nickname; }
    public void setNickname(String nickname) { this.nickname = nickname; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public String getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(String dateOfBirth) { this.dateOfBirth = dateOfBirth; }

    public String getCif() { return cif; }
    public void setCif(String cif) { this.cif = cif; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getDeviceNumber() { return deviceNumber; }
    public void setDeviceNumber(String deviceNumber) { this.deviceNumber = deviceNumber; }
}
