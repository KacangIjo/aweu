package com.example.videokycapi.model;


public class CustomerRequestModel{

    private String userNik;
    private String messageGuid;

    public String getUserNik() {
        return userNik;
    }

    public void setUserNik(String userNik) {
        this.userNik = userNik;
    }

    public String getMessageGuid() {
        return messageGuid;
    }

    public void setMessageGuid(String messageGuid) {
        this.messageGuid = messageGuid;
    }
}
