package com.example.videokycapi.controller;

import com.example.videokycapi.model.KYCDetailModel;
import com.example.videokycapi.model.KYCDetailRequestModel;
import com.example.videokycapi.service.IKycDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.*;

@RestController
public class KYCDetailController {

    @Autowired
    private IKycDetailService kycDetailService;

    @GetMapping("/recorddetails")
    public List<KYCDetailModel> getAllRecordDetail() {
        return kycDetailService.getAllRecordDetail();
    }

    @PostMapping("/recorddetails/{guid}")
    public KYCDetailModel createRecordDetail(@PathVariable(value = "guid") String generatedGuid,
                                     @Valid @RequestBody KYCDetailRequestModel request) {

        return kycDetailService.save(generatedGuid, request);
    }

    @PostMapping("/recorddetailsagent/")
    public ResponseEntity createRecordDetailByAgent( @Valid @RequestBody KYCDetailRequestModel request){
        return kycDetailService.saveByAgent(request);
    }

    @PostMapping("/recorddetails/finish/{guid}")
    public ResponseEntity setFinish(@PathVariable(value = "guid") String guid,
                                                    @Valid @RequestBody KYCDetailRequestModel request) {

        return kycDetailService.finish(guid, request);
    }

    @PostMapping("/recorddetails/customer")
    public ResponseEntity setCustomerId(@Valid @RequestBody KYCDetailRequestModel request) {
        return kycDetailService.saveCustomer(request);
    }

    @PostMapping("/recorddetails/markdone")
    public ResponseEntity setMarkDone(@Valid @RequestBody KYCDetailRequestModel request) {
        return kycDetailService.markDone(request);
    }

    @PostMapping("/recorddetails/setvideostatus")
    public ResponseEntity setVideoStatus(@Valid @RequestBody KYCDetailRequestModel request) {
        return kycDetailService.setVideoStatus(request);
    }

    @PostMapping("/recorddetails/setAgentNotAvailable")
    public KYCDetailModel setKycStatus(@Valid @RequestBody KYCDetailRequestModel request) {
        return kycDetailService.agentNotAvailable(request);
    }

    @PostMapping("/customers/calls/rejected")
    public KYCDetailModel setKycRejected(@Valid @RequestBody KYCDetailRequestModel request) {
        return kycDetailService.rejectedByCustomer(request);
    }
}
