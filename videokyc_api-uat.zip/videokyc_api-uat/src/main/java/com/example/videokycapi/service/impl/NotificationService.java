package com.example.videokycapi.service.impl;

import com.example.videokycapi.model.KYCDetailModel;
import com.example.videokycapi.model.KYCDetailRequestModel;
import com.example.videokycapi.service.INotificationService;
import com.google.gson.Gson;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

@Service
public class NotificationService implements INotificationService {

    private OpenMediaService openMediaService;

    Logger logger= LogManager.getLogger(CustomerService.class);
    Gson gson = new Gson();

    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Override
    public String sendNotification(KYCDetailRequestModel request) {
        //set dulu semua, soalnya data udah pasti ada, nanti di save agent tinggal set starttime
        //kycstatus not answered by default. kalo di reject baru set kycstatus "rejected by customer"
        String messageId = UUID.randomUUID().toString();
        logger.error("Message Request Id : ".concat(messageId).concat("\n")
                .concat(new Object() {}
                        .getClass()
                        .getEnclosingMethod()
                        .getName())
                .concat("\n")
                .concat(gson.toJson(request)));
        Date date = new Date();

        try{
            Timestamp startTime=new Timestamp(dateFormat.parse(dateFormat.format(date)).getTime());
            KYCDetailModel model = openMediaService.getCustomerData(messageId, request.getCustomerId());
            model.setCustomerId(request.getCustomerId());
            model.setId(messageId);
            model.setTimeCreated(startTime);
            model.setAgentId(request.getAgentId());
            model.setInteractionId(request.getInteractionId());
            model.setKycStatus("Not Answered");
            return messageId;
        } catch (Exception e) {
            logger.error("Message Request Id : ".concat(messageId).concat("\n")
                    .concat(new Object() {}
                            .getClass()
                            .getEnclosingMethod()
                            .getName())
                    .concat("\n")
                    .concat(gson.toJson(e.getMessage())));
            return "ERROR";
        }
    }

    @Override
    public ResponseEntity sendTimeOutNotification(KYCDetailRequestModel request) {
        return null;
    }
}
