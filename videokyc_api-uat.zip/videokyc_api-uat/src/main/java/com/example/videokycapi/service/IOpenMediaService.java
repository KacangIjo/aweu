package com.example.videokycapi.service;

import com.example.videokycapi.model.KYCDetailModel;
import com.example.videokycapi.model.OpenMediaEncryptedModel;
import com.example.videokycapi.model.OpenMediaRequestModel;

import java.text.ParseException;

public interface IOpenMediaService {

    String callOpenMedia(OpenMediaRequestModel openMediaRequestModel);

    void closeOpenMedia(String interactionId);


    KYCDetailModel getCustomerData(String messageId, String cif);
}
